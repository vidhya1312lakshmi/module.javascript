//Push

const fruits = ["apple", "banana"];
fruits.push("cherry");
console.log(fruits); 

// Filter

const numbers = [1, 2, 3, 4, 5];
const evenNumbers = numbers.filter(num => num % 2 === 0);
console.log(evenNumbers); 

//Map

const nums = [1, 2, 3, 4];
const squaredNums = nums.map(num => num * num);
console.log(squaredNums); 