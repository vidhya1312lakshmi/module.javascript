//use const for event name & date and available seats

const EVENT_NAME = "My world 2025";
const EVENT_DATE = "May 25, 2025";
const AVAILABLE_SEATS = 250;

console.log(`Event: ${EVENT_NAME}`);
console.log(`Date: ${EVENT_DATE}`);
console.log(`Available Seats: ${AVAILABLE_SEATS}`);

//concenate event info using template literals

const eventInfo = `Event: ${EVENT_NAME}
Date: ${EVENT_DATE}
Available Seats: ${AVAILABLE_SEATS}`;

console.log(eventInfo);


//use ++ or -- to manage a seat count on regisration

let availableSeats = 250;

function register() {
    if (availableSeats > 0) {
        availableSeats--;
        console.log(`Registration successful! Seats left: ${availableSeats}`);
    } else {
        console.log("Sorry, no seats available.");
    }
}

function cancelRegistration() {
    availableSeats++; 
    console.log(`Registration canceled. Seats left: ${availableSeats}`);
}


register(); 
cancelRegistration(); 