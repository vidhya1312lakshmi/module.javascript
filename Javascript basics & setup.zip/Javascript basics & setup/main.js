let a = "Welcome to the Community Portal "
console.log(a);

window.onload= function(){
    alert("Page Fully Loaded!");
}